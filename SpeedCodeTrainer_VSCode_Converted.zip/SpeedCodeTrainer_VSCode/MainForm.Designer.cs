﻿namespace SpeedCodeTrainer
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.cmbLanguage = new System.Windows.Forms.ComboBox();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.cmbDifficulty = new System.Windows.Forms.ComboBox();
            this.rtbOriginalCode = new System.Windows.Forms.RichTextBox();
            this.rtbUserInput = new System.Windows.Forms.RichTextBox();
            this.btnQuizMode = new System.Windows.Forms.Button();
            this.lblDuration = new System.Windows.Forms.Label();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.lblErrors = new System.Windows.Forms.Label();
            this.lblLevel = new System.Windows.Forms.Label();
            this.panelStats = new System.Windows.Forms.Panel();
            this.lstHistory = new System.Windows.Forms.ListBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCodeTitle = new System.Windows.Forms.Label();
            this.lblInputTitle = new System.Windows.Forms.Label();
            this.lblHistoryTitle = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.guna2ColorTransition1 = new Guna.UI2.WinForms.Guna2ColorTransition(this.components);
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ButtonStart = new Guna.UI2.WinForms.Guna2Button();
            this.guna2ButtonReset = new Guna.UI2.WinForms.Guna2Button();
            this.guna2ButtonCheck = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.panelStats.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbLanguage
            // 
            this.cmbLanguage.BackColor = System.Drawing.Color.LightGray;
            this.cmbLanguage.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbLanguage.FormattingEnabled = true;
            this.cmbLanguage.Location = new System.Drawing.Point(20, 70);
            this.cmbLanguage.Name = "cmbLanguage";
            this.cmbLanguage.Size = new System.Drawing.Size(120, 23);
            this.cmbLanguage.TabIndex = 0;
            // 
            // cmbCategory
            // 
            this.cmbCategory.BackColor = System.Drawing.Color.LightGray;
            this.cmbCategory.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Location = new System.Drawing.Point(150, 70);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(120, 23);
            this.cmbCategory.TabIndex = 1;
            // 
            // cmbDifficulty
            // 
            this.cmbDifficulty.BackColor = System.Drawing.Color.LightGray;
            this.cmbDifficulty.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbDifficulty.FormattingEnabled = true;
            this.cmbDifficulty.Location = new System.Drawing.Point(280, 70);
            this.cmbDifficulty.Name = "cmbDifficulty";
            this.cmbDifficulty.Size = new System.Drawing.Size(120, 23);
            this.cmbDifficulty.TabIndex = 2;
            // 
            // rtbOriginalCode
            // 
            this.rtbOriginalCode.BackColor = System.Drawing.Color.WhiteSmoke;
            this.rtbOriginalCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbOriginalCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbOriginalCode.Font = new System.Drawing.Font("Consolas", 11F);
            this.rtbOriginalCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.rtbOriginalCode.Location = new System.Drawing.Point(8, 8);
            this.rtbOriginalCode.Name = "rtbOriginalCode";
            this.rtbOriginalCode.ReadOnly = true;
            this.rtbOriginalCode.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbOriginalCode.Size = new System.Drawing.Size(1131, 146);
            this.rtbOriginalCode.TabIndex = 3;
            this.rtbOriginalCode.Text = "";
            // 
            // rtbUserInput
            // 
            this.rtbUserInput.BackColor = System.Drawing.Color.WhiteSmoke;
            this.rtbUserInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbUserInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbUserInput.Font = new System.Drawing.Font("Consolas", 11F);
            this.rtbUserInput.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.rtbUserInput.Location = new System.Drawing.Point(8, 8);
            this.rtbUserInput.Name = "rtbUserInput";
            this.rtbUserInput.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbUserInput.Size = new System.Drawing.Size(1131, 146);
            this.rtbUserInput.TabIndex = 4;
            this.rtbUserInput.Text = "";
            // 
            // btnQuizMode
            // 
            this.btnQuizMode.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.btnQuizMode.Font = new System.Drawing.Font("Arial", 9F);
            this.btnQuizMode.Location = new System.Drawing.Point(682, 479);
            this.btnQuizMode.Name = "btnQuizMode";
            this.btnQuizMode.Size = new System.Drawing.Size(100, 30);
            this.btnQuizMode.TabIndex = 8;
            this.btnQuizMode.Text = "Quiz ";
            this.btnQuizMode.UseVisualStyleBackColor = false;
            this.btnQuizMode.Click += new System.EventHandler(this.btnQuizMode_Click);
            // 
            // lblDuration
            // 
            this.lblDuration.AutoSize = true;
            this.lblDuration.Font = new System.Drawing.Font("Arial", 9F);
            this.lblDuration.Location = new System.Drawing.Point(420, 75);
            this.lblDuration.Name = "lblDuration";
            this.lblDuration.Size = new System.Drawing.Size(117, 15);
            this.lblDuration.TabIndex = 9;
            this.lblDuration.Text = "Длительность (с): 0";
            // 
            // lblSpeed
            // 
            this.lblSpeed.AutoSize = true;
            this.lblSpeed.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblSpeed.Location = new System.Drawing.Point(10, 20);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(113, 15);
            this.lblSpeed.TabIndex = 10;
            this.lblSpeed.Text = "Speed: 0 симв/мин";
            // 
            // lblErrors
            // 
            this.lblErrors.AutoSize = true;
            this.lblErrors.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblErrors.Location = new System.Drawing.Point(170, 20);
            this.lblErrors.Name = "lblErrors";
            this.lblErrors.Size = new System.Drawing.Size(56, 15);
            this.lblErrors.TabIndex = 11;
            this.lblErrors.Text = "Errors: 0";
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblLevel.Location = new System.Drawing.Point(280, 20);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(51, 15);
            this.lblLevel.TabIndex = 12;
            this.lblLevel.Text = "Level: --";
            // 
            // panelStats
            // 
            this.panelStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.panelStats.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStats.Controls.Add(this.lblSpeed);
            this.panelStats.Controls.Add(this.lblLevel);
            this.panelStats.Controls.Add(this.lblErrors);
            this.panelStats.Location = new System.Drawing.Point(20, 530);
            this.panelStats.Name = "panelStats";
            this.panelStats.Size = new System.Drawing.Size(1150, 60);
            this.panelStats.TabIndex = 13;
            // 
            // lstHistory
            // 
            this.lstHistory.Font = new System.Drawing.Font("Arial", 8F);
            this.lstHistory.FormattingEnabled = true;
            this.lstHistory.ItemHeight = 14;
            this.lstHistory.Location = new System.Drawing.Point(800, 624);
            this.lstHistory.Name = "lstHistory";
            this.lstHistory.Size = new System.Drawing.Size(370, 60);
            this.lstHistory.TabIndex = 14;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Arial Black", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTitle.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblTitle.Location = new System.Drawing.Point(17, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(404, 31);
            this.lblTitle.TabIndex = 15;
            this.lblTitle.Text = "Code Typer — тренажёр печати";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // lblCodeTitle
            // 
            this.lblCodeTitle.AutoSize = true;
            this.lblCodeTitle.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblCodeTitle.Location = new System.Drawing.Point(20, 110);
            this.lblCodeTitle.Name = "lblCodeTitle";
            this.lblCodeTitle.Size = new System.Drawing.Size(133, 16);
            this.lblCodeTitle.TabIndex = 16;
            this.lblCodeTitle.Text = "Текст для набора:";
            // 
            // lblInputTitle
            // 
            this.lblInputTitle.AutoSize = true;
            this.lblInputTitle.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblInputTitle.Location = new System.Drawing.Point(20, 300);
            this.lblInputTitle.Name = "lblInputTitle";
            this.lblInputTitle.Size = new System.Drawing.Size(81, 16);
            this.lblInputTitle.TabIndex = 17;
            this.lblInputTitle.Text = "Ваш ввод:";
            // 
            // lblHistoryTitle
            // 
            this.lblHistoryTitle.AutoSize = true;
            this.lblHistoryTitle.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblHistoryTitle.Location = new System.Drawing.Point(797, 603);
            this.lblHistoryTitle.Name = "lblHistoryTitle";
            this.lblHistoryTitle.Size = new System.Drawing.Size(114, 15);
            this.lblHistoryTitle.TabIndex = 18;
            this.lblHistoryTitle.Text = "История скорости:";
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            // 
            // guna2ColorTransition1
            // 
            this.guna2ColorTransition1.ColorArray = new System.Drawing.Color[] {
        System.Drawing.Color.Red,
        System.Drawing.Color.Blue,
        System.Drawing.Color.Orange};
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel2.BorderRadius = 12;
            this.guna2Panel2.Controls.Add(this.rtbUserInput);
            this.guna2Panel2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel2.Location = new System.Drawing.Point(23, 135);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Padding = new System.Windows.Forms.Padding(8);
            this.guna2Panel2.ShadowDecoration.Enabled = true;
            this.guna2Panel2.Size = new System.Drawing.Size(1147, 162);
            this.guna2Panel2.TabIndex = 20;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel1.BorderRadius = 12;
            this.guna2Panel1.Controls.Add(this.rtbOriginalCode);
            this.guna2Panel1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel1.Location = new System.Drawing.Point(23, 319);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Padding = new System.Windows.Forms.Padding(8);
            this.guna2Panel1.ShadowDecoration.Enabled = true;
            this.guna2Panel1.Size = new System.Drawing.Size(1147, 162);
            this.guna2Panel1.TabIndex = 21;
            // 
            // guna2ButtonStart
            // 
            this.guna2ButtonStart.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2ButtonStart.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2ButtonStart.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2ButtonStart.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2ButtonStart.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2ButtonStart.ForeColor = System.Drawing.Color.White;
            this.guna2ButtonStart.Location = new System.Drawing.Point(23, 487);
            this.guna2ButtonStart.Name = "guna2ButtonStart";
            this.guna2ButtonStart.Size = new System.Drawing.Size(148, 37);
            this.guna2ButtonStart.TabIndex = 22;
            this.guna2ButtonStart.Text = "Start";
            this.guna2ButtonStart.Click += new System.EventHandler(this.guna2ButtonStart_Click);
            // 
            // guna2ButtonReset
            // 
            this.guna2ButtonReset.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2ButtonReset.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2ButtonReset.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2ButtonReset.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2ButtonReset.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2ButtonReset.ForeColor = System.Drawing.Color.White;
            this.guna2ButtonReset.Location = new System.Drawing.Point(343, 487);
            this.guna2ButtonReset.Name = "guna2ButtonReset";
            this.guna2ButtonReset.Size = new System.Drawing.Size(136, 37);
            this.guna2ButtonReset.TabIndex = 23;
            this.guna2ButtonReset.Text = "Reset";
            this.guna2ButtonReset.Click += new System.EventHandler(this.guna2ButtonReset_Click);
            // 
            // guna2ButtonCheck
            // 
            this.guna2ButtonCheck.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2ButtonCheck.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2ButtonCheck.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2ButtonCheck.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2ButtonCheck.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2ButtonCheck.ForeColor = System.Drawing.Color.White;
            this.guna2ButtonCheck.Location = new System.Drawing.Point(194, 487);
            this.guna2ButtonCheck.Name = "guna2ButtonCheck";
            this.guna2ButtonCheck.Size = new System.Drawing.Size(128, 37);
            this.guna2ButtonCheck.TabIndex = 5;
            this.guna2ButtonCheck.Text = "Check";
            this.guna2ButtonCheck.Click += new System.EventHandler(this.guna2ButtonCheck_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(494, 487);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(134, 37);
            this.guna2Button1.TabIndex = 25;
            this.guna2Button1.Text = "Quiz";
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1180, 706);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.guna2ButtonCheck);
            this.Controls.Add(this.guna2ButtonReset);
            this.Controls.Add(this.guna2ButtonStart);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.lblHistoryTitle);
            this.Controls.Add(this.lblInputTitle);
            this.Controls.Add(this.lblCodeTitle);
            this.Controls.Add(this.lstHistory);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.panelStats);
            this.Controls.Add(this.lblDuration);
            this.Controls.Add(this.btnQuizMode);
            this.Controls.Add(this.cmbDifficulty);
            this.Controls.Add(this.cmbCategory);
            this.Controls.Add(this.cmbLanguage);
            this.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.Color.Gray;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(20);
            this.Text = "Code Typer — тренажёр печати";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panelStats.ResumeLayout(false);
            this.panelStats.PerformLayout();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbLanguage;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.ComboBox cmbDifficulty;
        private System.Windows.Forms.RichTextBox rtbOriginalCode;
        private System.Windows.Forms.RichTextBox rtbUserInput;
        private System.Windows.Forms.Button btnQuizMode;
        private System.Windows.Forms.Label lblDuration;
        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.Label lblErrors;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.Panel panelStats;
        private System.Windows.Forms.ListBox lstHistory;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblCodeTitle;
        private System.Windows.Forms.Label lblInputTitle;
        private System.Windows.Forms.Label lblHistoryTitle;
        private System.Windows.Forms.Timer timer;
        private Guna.UI2.WinForms.Guna2ColorTransition guna2ColorTransition1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Button guna2ButtonStart;
        private Guna.UI2.WinForms.Guna2Button guna2ButtonReset;
        private Guna.UI2.WinForms.Guna2Button guna2ButtonCheck;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}