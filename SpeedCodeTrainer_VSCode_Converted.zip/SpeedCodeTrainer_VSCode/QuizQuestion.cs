﻿using System.Collections.Generic;

namespace SpeedCodeTrainer
{
    public class QuizQuestion
    {
        public string Question { get; set; }
        public string CorrectAnswer { get; set; }
        public List<string> TestCases { get; set; } = new List<string>();
    }
}