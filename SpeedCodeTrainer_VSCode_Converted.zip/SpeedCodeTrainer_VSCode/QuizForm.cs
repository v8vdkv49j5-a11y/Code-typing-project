﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SpeedCodeTrainer
{
    public partial class QuizForm : Form
    {
        private Dictionary<string, Dictionary<string, List<QuizQuestion>>> quizDatabase;
        private QuizQuestion currentQuestion;

        private ComboBox cmbQuizLanguage, cmbQuizCategory;
        private Label lblQuestion;
        private RichTextBox rtbAnswer;
        private Button btnCheckAnswer, btnNewQuestion;
        private Label lblResult;

        public QuizForm()
        {
            InitializeComponent();
            InitializeQuizDatabase();
            CreateControls();
        }

        private void InitializeQuizDatabase()
        {
            quizDatabase = new Dictionary<string, Dictionary<string, List<QuizQuestion>>>();

            // C# вопросы
            var csharpQuestions = new Dictionary<string, List<QuizQuestion>>();

            csharpQuestions["If-Else"] = new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "Напишите код на C#, который проверяет, является ли число четным. Используйте переменную 'number'.",
                    CorrectAnswer = "if (number % 2 == 0)\n{\n    Console.WriteLine(\"Even\");\n}\nelse\n{\n    Console.WriteLine(\"Odd\");\n}"
                }
            };

            csharpQuestions["Loops"] = new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "Напишите цикл for на C#, который выводит числа от 1 до 10.",
                    CorrectAnswer = "for (int i = 1; i <= 10; i++)\n{\n    Console.WriteLine(i);\n}"
                }
            };

            // Python вопросы
            var pythonQuestions = new Dictionary<string, List<QuizQuestion>>();
            pythonQuestions["If-Else"] = new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "Напишите код на Python, который проверяет, является ли число положительным. Используйте переменную 'num'.",
                    CorrectAnswer = "if num > 0:\n    print(\"Positive\")\nelse:\n    print(\"Non-positive\")"
                }
            };

            quizDatabase["C#"] = csharpQuestions;
            quizDatabase["Python"] = pythonQuestions;
            quizDatabase["C++"] = new Dictionary<string, List<QuizQuestion>>();
        }

        private void CreateControls()
        {
            this.BackColor = Color.White;
            this.Padding = new Padding(20);

            // Комбобоксы
            cmbQuizLanguage = new ComboBox();
            cmbQuizLanguage.Location = new Point(20, 20);
            cmbQuizLanguage.Size = new Size(120, 25);
            cmbQuizLanguage.Font = new Font("Arial", 9);
            this.Controls.Add(cmbQuizLanguage);

            cmbQuizCategory = new ComboBox();
            cmbQuizCategory.Location = new Point(150, 20);
            cmbQuizCategory.Size = new Size(120, 25);
            cmbQuizCategory.Font = new Font("Arial", 9);
            this.Controls.Add(cmbQuizCategory);

            // Вопрос
            lblQuestion = new Label();
            lblQuestion.Location = new Point(20, 60);
            lblQuestion.Size = new Size(800, 40);
            lblQuestion.Font = new Font("Arial", 11, FontStyle.Bold);
            this.Controls.Add(lblQuestion);

            // Ответ
            rtbAnswer = new RichTextBox();
            rtbAnswer.Location = new Point(20, 110);
            rtbAnswer.Size = new Size(800, 300);
            rtbAnswer.Font = new Font("Consolas", 11);
            rtbAnswer.BorderStyle = BorderStyle.FixedSingle;
            this.Controls.Add(rtbAnswer);

            // Кнопки
            btnCheckAnswer = new Button();
            btnCheckAnswer.Text = "Проверить ответ";
            btnCheckAnswer.Location = new Point(20, 430);
            btnCheckAnswer.Size = new Size(120, 35);
            btnCheckAnswer.BackColor = Color.LightBlue;
            btnCheckAnswer.Font = new Font("Arial", 9);
            this.Controls.Add(btnCheckAnswer);

            btnNewQuestion = new Button();
            btnNewQuestion.Text = "Новый вопрос";
            btnNewQuestion.Location = new Point(150, 430);
            btnNewQuestion.Size = new Size(120, 35);
            btnNewQuestion.BackColor = Color.LightGreen;
            btnNewQuestion.Font = new Font("Arial", 9);
            this.Controls.Add(btnNewQuestion);

            // Результат
            lblResult = new Label();
            lblResult.Location = new Point(280, 430);
            lblResult.Size = new Size(540, 100);
            lblResult.Font = new Font("Arial", 10);
            this.Controls.Add(lblResult);

            // Настройка комбобоксов
            cmbQuizLanguage.Items.AddRange(new string[] { "C#", "Python", "C++" });
            cmbQuizLanguage.SelectedIndex = 0;

            cmbQuizCategory.Items.AddRange(new string[] { "If-Else", "Loops", "Arrays", "Functions" });
            cmbQuizCategory.SelectedIndex = 0;

            // События
            cmbQuizLanguage.SelectedIndexChanged += (s, e) => LoadNewQuestion();
            cmbQuizCategory.SelectedIndexChanged += (s, e) => LoadNewQuestion();
            btnCheckAnswer.Click += (s, e) => CheckAnswer();
            btnNewQuestion.Click += (s, e) => LoadNewQuestion();

            LoadNewQuestion();
        }

        private void LoadNewQuestion()
        {
            string language = cmbQuizLanguage.SelectedItem?.ToString() ?? "C#";
            string category = cmbQuizCategory.SelectedItem?.ToString() ?? "If-Else";

            if (quizDatabase.ContainsKey(language) &&
                quizDatabase[language].ContainsKey(category) &&
                quizDatabase[language][category].Count > 0)
            {
                var questions = quizDatabase[language][category];
                currentQuestion = questions[new Random().Next(questions.Count)];

                lblQuestion.Text = currentQuestion.Question;
                rtbAnswer.Clear();
                lblResult.Text = "";
                lblResult.ForeColor = Color.Black;
            }
            else
            {
                lblQuestion.Text = "Вопросы для этой категории пока не добавлены.";
                currentQuestion = null;
            }
        }

        private void CheckAnswer()
        {
            if (currentQuestion == null) return;

            string userAnswer = rtbAnswer.Text.Trim();
            string correctAnswer = currentQuestion.CorrectAnswer.Trim();

            // Упрощенная проверка
            string normalizedUser = NormalizeCode(userAnswer);
            string normalizedCorrect = NormalizeCode(correctAnswer);

            if (normalizedUser == normalizedCorrect)
            {
                lblResult.Text = "✓ Правильно! Отличная работа!";
                lblResult.ForeColor = Color.Green;
            }
            else
            {
                lblResult.Text = "✗ Неправильно. Попробуйте еще раз.";
                lblResult.ForeColor = Color.Red;
            }
        }

        private string NormalizeCode(string code)
        {
            return new string(code.Where(c => !char.IsWhiteSpace(c)).ToArray()).ToLower();
        }
    }
}