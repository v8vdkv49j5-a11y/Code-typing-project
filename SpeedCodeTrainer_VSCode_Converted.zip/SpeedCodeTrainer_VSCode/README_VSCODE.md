# SpeedCodeTrainer — VS Code setup (WinForms)

This project was converted from .NET Framework (net472) to SDK-style **.NET 8 (net8.0-windows)** so it can be built/run conveniently in **Visual Studio Code**.

## Requirements (Windows)
- .NET 8 SDK
- VS Code + C# extension (Microsoft)

## Run
- Open this folder in VS Code
- Press **F5** (launch config: `SpeedCodeTrainer (WinForms)`), or use terminal:

```bash
dotnet restore
dotnet build
dotnet run
```

## Notes
- VS Code does **not** include WinForms visual designer. UI changes are made in `*.Designer.cs` or in code.
- If you get package restore errors, run `dotnet restore` and check internet access / NuGet.
