﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SpeedCodeTrainer
{
    public partial class MainForm : Form
    {
        private Random random = new Random();
        private DateTime startTime;
        private int totalCharsTyped = 0;
        private int errorsCount = 0;
        private bool isTypingStarted = false;

        private Dictionary<string, Dictionary<string, Dictionary<string, List<string>>>> codeDatabase;

        public MainForm()
        {
            InitializeComponent();
            InitializeCodeDatabase();
            SetupUI();
            AttachEvents();
        }

        private void InitializeCodeDatabase()
        {
            codeDatabase = new Dictionary<string, Dictionary<string, Dictionary<string, List<string>>>>();

            // C# коды
            var csharpCodes = new Dictionary<string, Dictionary<string, List<string>>>();

            csharpCodes["If-Else"] = new Dictionary<string, List<string>>
            {
                ["Small"] = new List<string> {
                    "if (number > 0)\n{\n    Console.WriteLine(\"Positive\");\n}\nelse\n{\n    Console.WriteLine(\"Negative\");\n}",
                    "int age = 18;\nif (age >= 18)\n{\n    Console.WriteLine(\"Adult\");\n}\nelse\n{\n    Console.WriteLine(\"Minor\");\n}"
                }
            };

            csharpCodes["Loops"] = new Dictionary<string, List<string>>
            {
                ["Small"] = new List<string> {
                    "for (int i = 0; i < 5; i++)\n{\n    Console.WriteLine(i);\n}",
                    "int i = 1;\nwhile (i <= 5)\n{\n    Console.WriteLine(i);\n    i++;\n}"
                }
            };

            csharpCodes["Arrays"] = new Dictionary<string, List<string>>
            {
                ["Small"] = new List<string> {
                    "int[] numbers = {1, 2, 3, 4, 5};\nforeach (int num in numbers)\n{\n    Console.WriteLine(num);\n}"
                }
            };

            // Python коды
            var pythonCodes = new Dictionary<string, Dictionary<string, List<string>>>();
            pythonCodes["If-Else"] = new Dictionary<string, List<string>>
            {
                ["Small"] = new List<string> {
                    "if number > 0:\n    print(\"Positive\")\nelse:\n    print(\"Negative\")",
                    "age = 18\nif age >= 18:\n    print(\"Adult\")\nelse:\n    print(\"Minor\")"
                }
            };

            // C++ коды
            var cppCodes = new Dictionary<string, Dictionary<string, List<string>>>();
            cppCodes["If-Else"] = new Dictionary<string, List<string>>
            {
                ["Small"] = new List<string> {
                    "if (number > 0)\n{\n    cout << \"Positive\" << endl;\n}\nelse\n{\n    cout << \"Negative\" << endl;\n}"
                }
            };

            codeDatabase["C#"] = csharpCodes;
            codeDatabase["Python"] = pythonCodes;
            codeDatabase["C++"] = cppCodes;
        }

        private void SetupUI()
        {
            cmbLanguage.Items.AddRange(new string[] { "C#", "Python", "C++" });
            cmbLanguage.SelectedIndex = 0;

            cmbCategory.Items.AddRange(new string[] { "If-Else", "Loops", "Arrays", "Functions", "Classes" });
            cmbCategory.SelectedIndex = 0;

            cmbDifficulty.Items.AddRange(new string[] { "Small", "Medium", "Large" });
            cmbDifficulty.SelectedIndex = 0;

            LoadNewCode();
        }

        private void AttachEvents()
        {
            cmbLanguage.SelectedIndexChanged += (s, e) => LoadNewCode();
            cmbCategory.SelectedIndexChanged += (s, e) => LoadNewCode();
            cmbDifficulty.SelectedIndexChanged += (s, e) => LoadNewCode();
            guna2ButtonStart.Click += (s, e) => StartTyping();
            guna2ButtonCheck.Click += (s, e) => CheckCode();
            guna2ButtonReset.Click += (s, e) => ResetTest();
            btnQuizMode.Click += (s, e) => { new QuizForm().ShowDialog(); };
            rtbUserInput.TextChanged += (s, e) => UpdateHighlighting();
            rtbUserInput.KeyDown += (s, e) => { if (e.KeyCode == Keys.Tab) { e.SuppressKeyPress = true; InsertTab(); } };
            timer.Tick += Timer_Tick;
        }

        private void LoadNewCode()
        {
            string language = cmbLanguage.SelectedItem?.ToString() ?? "C#";
            string category = cmbCategory.SelectedItem?.ToString() ?? "If-Else";
            string difficulty = cmbDifficulty.SelectedItem?.ToString() ?? "Small";

            if (codeDatabase.ContainsKey(language) &&
                codeDatabase[language].ContainsKey(category) &&
                codeDatabase[language][category].ContainsKey(difficulty))
            {
                var codes = codeDatabase[language][category][difficulty];
                string selectedCode = codes[random.Next(codes.Count)];
                rtbOriginalCode.Text = selectedCode;
            }
            else
            {
                rtbOriginalCode.Text = "// Код для выбранной категории пока не добавлен";
            }

            ResetTest();
        }

        private void StartTyping()
        {
            if (!isTypingStarted)
            {
                isTypingStarted = true;
                startTime = DateTime.Now;
                timer.Start();
                rtbUserInput.Focus();
            }
        }

        private void CheckCode()
        {
            timer.Stop();
            CalculateStatistics();

            string userCode = rtbUserInput.Text;
            string originalCode = rtbOriginalCode.Text;

            if (userCode == originalCode)
            {
                MessageBox.Show("Правильно! Код полностью совпадает.", "Результат",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Есть ошибки. Проверьте ваш код.", "Результат",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ResetTest()
        {
            timer.Stop();
            rtbUserInput.Clear();
            isTypingStarted = false;
            totalCharsTyped = 0;
            errorsCount = 0;
            lblSpeed.Text = "Speed: 0 симв/мин";
            lblErrors.Text = "Errors: 0";
            lblLevel.Text = "Level: --";
            lblDuration.Text = "Длительность (с): 0";
            lstHistory.Items.Clear();
            UpdateHighlighting();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (isTypingStarted)
            {
                TimeSpan elapsed = DateTime.Now - startTime;
                lblDuration.Text = $"Длительность (с): {(int)elapsed.TotalSeconds}";
                CalculateStatistics();
            }
        }

        private void CalculateStatistics()
        {
            if (!isTypingStarted) return;

            TimeSpan elapsed = DateTime.Now - startTime;
            double minutes = elapsed.TotalMinutes;

            if (minutes > 0)
            {
                int cpm = (int)(totalCharsTyped / minutes);
                lblSpeed.Text = $"Speed: {cpm} симв/мин";

                // Добавляем в историю каждые 10 секунд
                if ((int)elapsed.TotalSeconds % 10 == 0 && (int)elapsed.TotalSeconds > 0)
                {
                    if (lstHistory.Items.Count == 0 || !lstHistory.Items[lstHistory.Items.Count - 1].ToString().Contains($"{cpm} симв/мин"))
                    {
                        lstHistory.Items.Add($"{DateTime.Now:HH:mm:ss} - {cpm} симв/мин");
                        if (lstHistory.Items.Count > 10)
                            lstHistory.Items.RemoveAt(0);
                    }
                }

                // Определяем уровень
                if (cpm > 200) lblLevel.Text = "Level: Expert";
                else if (cpm > 150) lblLevel.Text = "Level: Advanced";
                else if (cpm > 100) lblLevel.Text = "Level: Intermediate";
                else if (cpm > 50) lblLevel.Text = "Level: Beginner";
                else lblLevel.Text = "Level: Novice";
            }
        }

        private void UpdateHighlighting()
        {
            if (!isTypingStarted && rtbUserInput.Text.Length > 0)
            {
                StartTyping();
            }

            string userText = rtbUserInput.Text;
            string originalText = rtbOriginalCode.Text;

            // Подсветка символов
            rtbOriginalCode.SelectAll();
            rtbOriginalCode.SelectionColor = Color.Gray;

            errorsCount = 0;
            totalCharsTyped = userText.Length;

            for (int i = 0; i < Math.Min(userText.Length, originalText.Length); i++)
            {
                rtbOriginalCode.Select(i, 1);
                if (userText[i] == originalText[i])
                {
                    rtbOriginalCode.SelectionColor = Color.Green;
                }
                else
                {
                    rtbOriginalCode.SelectionColor = Color.Red;
                    errorsCount++;
                }
            }

            lblErrors.Text = $"Errors: {errorsCount}";
            rtbOriginalCode.Select(0, 0);
        }

        private void InsertTab()
        {
            int selectionStart = rtbUserInput.SelectionStart;
            rtbUserInput.Text = rtbUserInput.Text.Insert(selectionStart, "    ");
            rtbUserInput.SelectionStart = selectionStart + 4;
        }

        private void btnQuizMode_Click(object sender, EventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {
        

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2ButtonCheck_Click(object sender, EventArgs e)
        {
            timer.Stop();
            CalculateStatistics();

            string userCode = rtbUserInput.Text;
            string originalCode = rtbOriginalCode.Text;

            if (userCode == originalCode)
            {
                MessageBox.Show("Правильно! Код полностью совпадает.",
                    "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Есть ошибки. Проверьте ваш код.",
                    "Результат", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void guna2ButtonStart_Click(object sender, EventArgs e)
        {
            if (!isTypingStarted)
            {
                isTypingStarted = true;
                startTime = DateTime.Now;
                timer.Start();
                rtbUserInput.Clear();
                rtbUserInput.Focus();
            }
        }

        private void guna2ButtonReset_Click(object sender, EventArgs e)
        {
            timer.Stop();
            rtbUserInput.Clear();
            isTypingStarted = false;
            totalCharsTyped = 0;
            errorsCount = 0;

            lblSpeed.Text = "Speed: 0 симв/мин";
            lblErrors.Text = "Errors: 0";
            lblLevel.Text = "Level: --";
            lblDuration.Text = "Длительность (с): 0";
            lstHistory.Items.Clear();

            LoadNewCode();
            rtbUserInput.Focus();
        }
    }
}